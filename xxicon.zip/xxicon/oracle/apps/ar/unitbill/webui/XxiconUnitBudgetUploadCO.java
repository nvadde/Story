/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package xxicon.oracle.apps.ar.unitbill.webui;

import java.io.Serializable;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

import oracle.cabo.ui.data.DataObject;

import oracle.jbo.Transaction;
import oracle.jbo.domain.BlobDomain;

/**
 * Controller for ...
 */
public class XxiconUnitBudgetUploadCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
      OAApplicationModule am = pageContext.getApplicationModule(webBean);
      if (pageContext.getParameter("Save") != null )
      {
          DataObject fileUploadData = (DataObject)pageContext.getNamedDataObject("BillUnitUploadItem");
          String fileName = null;
          if (fileUploadData != null)
          {
              System.out.println("This is inside fileUploadData ");
              try
              {
                  fileName = (String)fileUploadData.selectValue(null, "UPLOAD_FILE_NAME");
                  System.out.println(" The file "+ fileName);
              }
              catch(NullPointerException ex)
              {
                  throw new OAException("Please Select a File to Upload", OAException.ERROR);
              }
              
              BlobDomain uploadedByteStream = (BlobDomain)fileUploadData.selectValue(null, fileName);
              try
              {
                // OAApplicationModule am = pageContext.getRootApplicationModule();
                 Serializable aserializable2[] = {fileName,uploadedByteStream};
                 Class aclass2[] = {String.class,BlobDomain.class };
                 am.invokeMethod("ReadExcel",aserializable2,aclass2);
              }
              catch (Exception ex)
              {
               throw new OAException(ex.toString(), OAException.ERROR);
              }
          }
      }
      
      if (pageContext.getParameter("Cancel") != null )
      {
          Transaction trx = am.getTransaction();     
          if (trx.isDirty())
          {
              trx.rollback();
          } 
      }
      
      if (pageContext.getParameter("Search") != null )
      {
          pageContext.forwardImmediately("OA.jsp?page=/xxicon/oracle/apps/ar/unitbill/webui/XxiconUnitBudgetSearchPG",
                                                      null,
                                                      OAWebBeanConstants.KEEP_MENU_CONTEXT,
                                                      null, null, true,
                                                      OAWebBeanConstants.ADD_BREAD_CRUMB_NO);
      }
  }

}
