/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package xxicon.oracle.apps.ar.unitbill.webui;

import java.io.Serializable;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.layout.OAQueryBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageCheckBoxBean;

import xxicon.oracle.apps.ar.unitbill.server.XxiconBudgetSearchVOImpl;
//import oracle.apps.fnd.framework.webui.beans.layout.OAQueryBean;

/**
 * Controller for ...
 */
public class XxiconUnitBudgetSearchCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
    
    OAApplicationModule am = pageContext.getApplicationModule(webBean);

    if (pageContext.getParameter("searchBtn") != null)
    {     
        
        String searchOU       = pageContext.getParameter("SearchOperatingUnit");;
        String searchProjNum  = pageContext.getParameter("SearchProjectNum");
        String searchProjMgr  = pageContext.getParameter("SearchProjectManager");
        
        OAMessageCheckBoxBean cb = (OAMessageCheckBoxBean)webBean.findIndexedChildRecursive("SearchLatestVersion");
        String cbval = (String)cb.getValue(pageContext);
       // System.out.println(" Latest checked value "+ cbval);
        
        Serializable ser[] = {cbval, searchOU, searchProjNum, searchProjMgr};
        
        am.invokeMethod("initBudgetLatestSearch", ser);
    }
    
    if (pageContext.getParameter("clearBtn") != null)
    {
        pageContext.setForwardURLToCurrentPage(null, false, null, OAWebBeanConstants.IGNORE_MESSAGES); 
    }
    
      if (pageContext.getParameter("uploadBtn") != null)
      {
          pageContext.forwardImmediately("OA.jsp?page=/xxicon/oracle/apps/ar/unitbill/webui/XxiconUnitBudgetUploadPG",
                                                      null,
                                                      OAWebBeanConstants.KEEP_MENU_CONTEXT,
                                                      null, null, true,
                                                      OAWebBeanConstants.ADD_BREAD_CRUMB_NO);
      }
  }

}
