/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package xxicon.oracle.apps.ar.unitbill.webui;

import java.io.Serializable;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

import oracle.apps.fnd.framework.webui.beans.message.OAMessageCheckBoxBean;

import oracle.jbo.Transaction;
import oracle.jbo.domain.BlobDomain;

import xxicon.oracle.apps.ar.unitbill.server.XxiconBudgetHeadersVOImpl;
import xxicon.oracle.apps.ar.unitbill.server.XxiconBudgetHeadersVORowImpl;

/**
 * Controller for ...
 */
public class XxiconUnitBudgetCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
    
      OAApplicationModule am = pageContext.getApplicationModule(webBean);
      String projNum    = pageContext.getParameter("SearchProjectNum");
      String projVerNum = pageContext.getParameter("SearchVersionNum");
      
     // projNum = "00350215";
     // projVerNum = "1";
      
      Serializable serial[] = {projNum,projVerNum};
      am.invokeMethod("initBudgetHeader",serial);
      am.invokeMethod("initParentTask",serial);
      am.invokeMethod("intiPsTotal");
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
    OAApplicationModule am = pageContext.getApplicationModule(webBean);
    
    if (pageContext.getParameter("saveBtn") != null)
    {
        am.getOADBTransaction().commit();
        throw new OAException("Record saved successfully", OAException.INFORMATION);
    }
    
    if (pageContext.getParameter("cancelBtn") != null)
    {
        Transaction trx = am.getTransaction();     
        if (trx.isDirty())
        {
            trx.rollback();
        } 
    }
      
    if (pageContext.getParameter("baselineBtn") != null)
    {
        XxiconBudgetHeadersVOImpl hvo = (XxiconBudgetHeadersVOImpl)am.findViewObject("XxiconBudgetHeadersVO1");
        XxiconBudgetHeadersVORowImpl row  = (XxiconBudgetHeadersVORowImpl)hvo.first();
        row.setBaseLine("Y");
        
        am.getOADBTransaction().commit();
        throw new OAException("Budget Baselined successfully", OAException.INFORMATION);
    }
    
    if (pageContext.getParameter("inflationBtn") != null)
    {
        
    }
      
    if (pageContext.getParameter("backBtn") != null)
    {
        pageContext.forwardImmediately("OA.jsp?page=/xxicon/oracle/apps/ar/unitbill/webui/XxiconUnitBudgetSearchPG",
                                                    null,
                                                    OAWebBeanConstants.KEEP_MENU_CONTEXT,
                                                    null, null, true,
                                                    OAWebBeanConstants.ADD_BREAD_CRUMB_NO);
    }
  }

}
