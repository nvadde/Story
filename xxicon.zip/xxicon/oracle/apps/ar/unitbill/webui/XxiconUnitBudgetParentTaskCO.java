/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package xxicon.oracle.apps.ar.unitbill.webui;

import java.io.Serializable;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageCheckBoxBean;

import oracle.jbo.RowSetIterator;

import xxicon.oracle.apps.ar.unitbill.server.XxiconBudgetHeadersVOImpl;
import xxicon.oracle.apps.ar.unitbill.server.XxiconBudgetHeadersVORowImpl;
import xxicon.oracle.apps.ar.unitbill.server.XxiconBudgetParentTaskVOImpl;
import xxicon.oracle.apps.ar.unitbill.server.XxiconBudgetParentTaskVORowImpl;

/**
 * Controller for ...
 */
public class XxiconUnitBudgetParentTaskCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
      OAApplicationModule am = pageContext.getApplicationModule(webBean);
    
      String source = pageContext.getParameter(SOURCE_PARAM);
      String event = pageContext.getParameter(EVENT_PARAM);
      
      //System.out.println(" source TaskCO => "+ source);
     // System.out.println(" event  TaskCO => "+ event);
    
    if ( event.equalsIgnoreCase("eventExpandCollapse"))
    {
       // System.out.println(" This is inside UnitBudgetParentTaskCO ");
        OAMessageCheckBoxBean cb = (OAMessageCheckBoxBean)webBean.findChildRecursive("itemExpandCollapse");
        
        if (cb != null)
        {
            String cbval = (String)cb.getValue(pageContext);          
          //  System.out.println(" The value of cbval "+ cbval);
            XxiconBudgetParentTaskVOImpl vo = (XxiconBudgetParentTaskVOImpl)am.findViewObject("XxiconBudgetParentTaskVO1");
            if (cbval.equalsIgnoreCase(("Y")))
            {
                
                XxiconBudgetParentTaskVORowImpl row = null;
                int fetchedRowCount = vo.getRowCount();
                RowSetIterator expItr = vo.createRowSetIterator("expandItr");
                
                if(fetchedRowCount > 0)
                {
                   expItr.setRangeStart(0);
                   expItr.setRangeSize(fetchedRowCount);
                   for(int i=0; i<fetchedRowCount; i++)
                   {
                      row = (XxiconBudgetParentTaskVORowImpl)expItr.getRowAtRangeIndex(i);
                      if (cbval.equalsIgnoreCase(("Y")))
                      {        
                          row.setDetailFlag(true); 
                      }
                   } 
                 } 
                expItr.closeRowSetIterator();
            }
            else {
                pageContext.setForwardURLToCurrentPage(null, false, null, OAWebBeanConstants.IGNORE_MESSAGES);            
            }
         }     
    }

  }

}
